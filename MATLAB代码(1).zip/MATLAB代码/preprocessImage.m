function img28 = preprocessImage(imgPath)
%% preprocessImage - 统一预处理流程，输出28x28 logical，前景=1
% 供 recognizeDigit 调用

%% 读图+灰度
raw = imread(imgPath);
if size(raw,3)==3, gray=rgb2gray(raw); else, gray=raw; end

%% 高斯降噪
den = imgaussfilt(double(gray), 1.2);
den = uint8(den);

%% Otsu二值化
bw = imbinarize(den, graythresh(den));

%% 前景统一为1（数字区域=1）
if mean(bw(:)) > 0.5, bw = ~bw; end

%% 形态学
morph = imopen (bw,    strel('disk',1));
morph = imclose(morph, strel('disk',2));
morph = imfill (morph, 'holes');

%% 最大连通域裁剪
CC = bwconncomp(morph);
if CC.NumObjects > 0
    st = regionprops(CC,'Area','BoundingBox');
    [~,mi] = max([st.Area]);
    bb = st(mi).BoundingBox;
    pad=3;
    x1=max(1,floor(bb(1))-pad); x2=min(size(morph,2),ceil(bb(1)+bb(3))+pad);
    y1=max(1,floor(bb(2))-pad); y2=min(size(morph,1),ceil(bb(2)+bb(4))+pad);
    morph = morph(y1:y2, x1:x2);
end

%% 缩放到28×28
img28 = logical(imresize(double(morph),[28,28]) > 0.5);
img28 = imdilate(img28, strel('disk',1));  % 笔画增粗，与训练样本一致
end
